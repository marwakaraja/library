﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Library_AccessData.Migrations
{
    public partial class addcountvariable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
